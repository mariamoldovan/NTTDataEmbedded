#include "mainwindow.h"
#include <QApplication>
#include "mygui.h"
#include "fifo.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyGUI gui;
    makeFIFO();
    gui.show();
    gui.testSenzori();
    //closeFIFO();

    return a.exec();
}
