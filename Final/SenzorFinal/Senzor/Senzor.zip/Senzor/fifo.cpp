#include "fifo.h"


#define MAX_BUF 1024

void makeFIFO()
{
    //unlink("/home/pi/Senzor/FIFO/myfifo");
    char* myfifo = "/home/pi/Senzor/FIFO/myfifo";

    // create the FIFO (named pipe)
    int res = mkfifo(myfifo, 0666);
}

void closeFIFO()
{
    char* myfifo = "/home/pi/Senzor/FIFO/myfifo";
    // remove the FIFO
    unlink(myfifo);
}

void FIFOcommunicate(int dist[], bool &franaDeMana)
{
    char* myfifo = "/home/pi/Senzor/FIFO/myfifo";
    // open the FIFO
        int fd = open(myfifo, O_WRONLY);
        /*if (fd == -1)
        {
            perror("open() error: ");
            exit(EXIT_FAILURE);
        }*/

        // write a string to the FIFO
        char msg[]="Send data!";
        write(fd, msg, sizeof(msg));
    //	printf("Data requiest was send!");
        close(fd);


        char buf[MAX_BUF];

        // open the FIFO for reading
        fd = open(myfifo, O_RDONLY);
        /*if (fd == -1)
        {
            perror("open() error: ");
            exit(EXIT_FAILURE);
        }
    */
        // read message from FIFO
        read(fd, buf, MAX_BUF);
        char* token=strtok(buf, " ");
        //printf("%s\n", buf);
        /*int i=0;
        while (token)
        {
            dist[i++]=atoi(token);
            token=strtok(NULL, " ");
        }
        if (dist[5]==0)
            franaDeMana=0;
        else
            franaDeMana=1;
        */

        int i=0;
        while (token)
        {
            dist[i++]=atoi(token);
            token=strtok(NULL, " ");
        }
        if (dist[5]==0)
            franaDeMana=0;
        else
            franaDeMana=1;


        close(fd);
}
