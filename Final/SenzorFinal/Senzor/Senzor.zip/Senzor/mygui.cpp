#include "mygui.h"
#include "ui_mygui.h"

#include <QPainter>
#include <QColor>
#include <QVBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <QStackedWidget>
#include <QtSvg>
#include <QPixmap>
#include <fifo.h>

MyGUI::MyGUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyGUI)
{
    ui->setupUi(this);
    initGUI();
}

MyGUI::~MyGUI()
{
    delete ui;
}

void MyGUI::updateSenzors(int distante[], bool franaDeMana)
{
    for (int senzor_id=0; senzor_id<5; senzor_id++)
        senzori[senzor_id]->updateSenzor(distante[senzor_id], franaDeMana);
}


void MyGUI::initGUI()
{
    this->setLayout(ui->windowLayout);
    ui->windowLayout->setContentsMargins(20,20,20,20);
   // ui->senzorWidget->raise();
    this->constructSenzors();
    QObject::connect(ui->volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(sendVolume(int)));
    QObject::connect(ui->volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(changeVolumeLabel(int)));
    QPixmap pixmap(":/Resources/VolumeImg/vol0.png");
    ui->volumeImage->setPixmap(pixmap);

}

void MyGUI::constructSenzors()
{
    QStackedLayout* senzorsLayout = new QStackedLayout{};

    senzorsLayout->setStackingMode(QStackedLayout::StackAll);
    ui->senzorWidget->setLayout(senzorsLayout);
    ui->windowLayout->addWidget(ui->senzorWidget);

    for (int i=0; i<5; i++)
    {
        Senzor* s = new Senzor{i+1, 150, 5};
        senzori.push_back(s);
        senzori[i]->drawSenzor();
        senzorsLayout->addWidget(senzori[i]->senzorFrame);

    }

    QSvgWidget* car= new QSvgWidget{QString::fromStdString(":/Resources/SenzorSVG/car.svg")};
    senzorsLayout->addWidget(car);

    QSvgWidget* frame= new QSvgWidget{QString::fromStdString(":/Resources/SenzorSVG/frame.svg")};
    senzorsLayout->addWidget(frame);
}


void MyGUI::myWait(int seconds)
{
    QTime dieTime= QTime::currentTime().addSecs(seconds);
    while (QTime::currentTime() < dieTime)
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);

}

void MyGUI::changeVolumeLabel(int volume)
{
    int nrVolumeImage;
    if (volume==0)
        nrVolumeImage=0;
    else
        if (volume==99)
            nrVolumeImage=3;
        else
            nrVolumeImage=volume/33+1;
    QPixmap pixmap(":/Resources/VolumeImg/vol"+QString::number(nrVolumeImage)+".png");
    ui->volumeImage->setPixmap(pixmap);
}

void MyGUI::testSenzori()
{
    srand (time(NULL));

    while (true)
    {
        int dist[6];
        /*for (int i=0; i<5; i++)
            dist[i] = rand()%150;*/
        bool franaDeMana=0;
        FIFOcommunicate(dist, franaDeMana);
        //bool franaDeMana = rand()%2;
        updateSenzors(dist, franaDeMana);
        myWait(this->getFREQ());
    }

}

void MyGUI::sendVolume(int volume)
{
    ui->volumeValue->setText(QString::number(volume));

}
