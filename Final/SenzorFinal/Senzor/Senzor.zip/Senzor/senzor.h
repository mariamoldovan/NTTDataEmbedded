#ifndef SENZOR_H
#define SENZOR_H

#include <vector>
#include <QPainter>
#include <QLabel>
#include <QStackedLayout>
#include <QtSvg>
class Senzor
{
private:
    int ID;
    int DIST_MAX=150;
    int NR_SEGM=5;
    int DIST_ACTUALA;


public:
    QWidget * senzorFrame;
    QStackedLayout * senzorLayout;
    std::vector<QSvgWidget*> segments;

    Senzor();
    Senzor(const int ID, const int DIST_MAX, const int NR_SEGM);

    int getID() const { return ID; }

    int getNR_SEGM() const { return NR_SEGM; }
    void setNR_SEGM(const int NR_SEGM);

    int getDIST_MAX() const { return DIST_MAX; }    
    void setDIST_MAX(const int DIST_MAX);

    int getDIST_ACTUALA() const { return DIST_ACTUALA; }
    void setDIST_ACTUALA(const int DIST_ACTUALA);

    void updateSenzor(const int DIST_ACTUALA, const bool franaDeMana);

    void drawSenzor();


};

#endif // SENZOR_H
