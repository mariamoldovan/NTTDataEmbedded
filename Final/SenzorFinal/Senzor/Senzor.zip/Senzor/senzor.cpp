#include "senzor.h"
#include "senzorlayout.h"
#include <QWidget>
#include <QHBoxLayout>
#include <QLabel>
Senzor::Senzor()
{

}

Senzor::Senzor(const int ID, const int DIST_MAX, const int NR_SEGM)
{
    this->ID=ID;
    this->DIST_MAX= DIST_MAX;
    this->NR_SEGM= NR_SEGM;
}

void Senzor::setNR_SEGM(const int NR_SEGM)
{
    this->NR_SEGM=NR_SEGM;
}

void Senzor::setDIST_MAX(const int DIST_MAX)
{
    this->DIST_MAX=DIST_MAX;
}

void Senzor::setDIST_ACTUALA(const int DIST_ACTUALA)
{
    this->DIST_ACTUALA=DIST_ACTUALA;
}

void Senzor::updateSenzor(const int DIST_ACTUALA, const bool franaDeMana)
{
    setDIST_ACTUALA(DIST_ACTUALA);
    int nrSegment;
    if (DIST_ACTUALA<0 || DIST_ACTUALA>150)
        nrSegment=0;
    else
        if (franaDeMana)
            nrSegment= this->getDIST_ACTUALA()/30+6;
        else
            nrSegment= this->getDIST_ACTUALA()/30+1;
    senzorLayout->setCurrentIndex(nrSegment);
}

void Senzor::drawSenzor()
{
    this->senzorFrame = new QWidget{};
    this->senzorLayout = new QStackedLayout{};
    this->senzorFrame->setLayout(this->senzorLayout);

    QSvgWidget* seg= new QSvgWidget{":/Resources/SenzorSVG/empty.svg"};
    this->segments.push_back(seg);
    this->senzorLayout->addWidget(this->segments[0]);

   for (int i=1; i<=this->getNR_SEGM(); i++)
   {
       QSvgWidget* seg= new QSvgWidget{QString::fromStdString(":/Resources/SenzorSVG/s"+std::to_string(this->getID()) + std::to_string(i)+ ".svg")};
       this->segments.push_back(seg);
       this->senzorLayout->addWidget(this->segments[i]);
   }
   for (int i=1; i<=this->getNR_SEGM(); i++)
   {
       QSvgWidget* seg= new QSvgWidget{QString::fromStdString(":/Resources/SenzorSVG/fs"+std::to_string(this->getID()) + std::to_string(i)+ ".svg")};
       this->segments.push_back(seg);
       this->senzorLayout->addWidget(this->segments[i+5]);
   }
}
