#ifndef buzzer
#define buzzer

#if (ARDUINO >=100)
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

// CONNECTION:
//   Pins  9 & 10 - ATmega328, ATmega128, ATmega640, ATmega8, Uno, Leonardo, etc.
//   Pins 11 & 12 - ATmega2560/2561, ATmega1280/1281, Mega
//   Pins 12 & 13 - ATmega1284P, ATmega644
//   Pins 14 & 15 - Teensy 2.0
//   Pins 25 & 26 - Teensy++ 2.0

class Buzzer {

  private://variabile private

    uint8_t PrivateDistantaSegment5 ;
    uint8_t PrivateDistantaSegment4;
    uint8_t PrivateDistantaSegment3 ;
    uint8_t PrivateDistantaSegment2 ;
    uint8_t PrivateDistantaSegment1 ;
    uint8_t PrivateDistantaSegment0 ;

    uint8_t PrivateFrecventaSegment5 ;
    uint8_t PrivateFrecventaSegment4 ;
    uint8_t PrivateFrecventaSegment3 ;
    uint8_t PrivateFrecventaSegment2 ;
    uint8_t PrivateFrecventaSegment1 ;
    uint8_t PrivateFrecventaSegment0 ;

    uint8_t PrivateDurataNotaSegment5 ;
    uint8_t PrivateDurataNotaSegment4 ;
    uint8_t PrivateDurataNotaSegment3 ;
    uint8_t PrivateDurataNotaSegment2 ;
    uint8_t PrivateDurataNotaSegment1 ;
    uint8_t PrivateDurataNotaSegment0 ;
    uint8_t PrivateNumarSenzori;
    
    static Buzzer* instance;
    
    Buzzer (
             uint8_t DistantaSegment5 ,
             uint8_t DistantaSegment4 ,
             uint8_t DistantaSegment3 ,
             uint8_t DistantaSegment2 ,
             uint8_t DistantaSegment1 ,
             uint8_t DistantaSegment0 ,

             uint8_t FrecventaSegment5 ,
             uint8_t FrecventaSegment4 ,
             uint8_t FrecventaSegment3 ,
             uint8_t FrecventaSegment2 ,
             uint8_t FrecventaSegment1 ,
             uint8_t FrecventaSegment0 ,

             uint8_t DurataNotaSegment5 ,
             uint8_t DurataNotaSegment4 ,
             uint8_t DurataNotaSegment3 ,
             uint8_t DurataNotaSegment2 ,
             uint8_t DurataNotaSegment1 ,
             uint8_t DurataNotaSegment0 ,

             uint8_t NumarSenzori
            ); //ructor


  public :
    static Buzzer* getinstance();
    //Metode
    void RingBuzzer(uint8_t SirDistante[], uint8_t Volum); //functie pentru a genera sunet de la buzzer fara parametri
    void SilentBuzzer();//functie pentru a opri sunetul generat de buzzer
};

#endif


