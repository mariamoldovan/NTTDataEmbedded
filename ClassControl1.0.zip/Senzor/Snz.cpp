#include <NewPing.h>
#include "Snz.h"
#include "ConfigSenzorUltrasonic.h"

InitSenzor::InitSenzor(uint8_t Id, uint8_t pinTrig, uint8_t pinEcho)
{
    PrivatePinTrig = pinTrig;
    PrivatePinEcho = pinEcho;
	IdSenzor = Id;
}

InitSenzor :: InitSenzor()
{
}

uint8_t InitSenzor::citesteDistanta()
{
  NewPing sonar(PrivatePinTrig, PrivatePinEcho, 400);
  uint16_t duration;
  duration = sonar.ping();
  distantaActuala = (duration / 2) / VitezaSunetCM;
  if (distantaActuala >= DistantaMaximaSenzor || distantaActuala < DistantaMinimaSenzor) {
    return OutOfRange;
  }
  else {
    return distantaActuala;
  }
}

uint8_t InitSenzor::getId()
{
	return IdSenzor;
}

