#include "Arduino.h"

class InitSenzor
{
  
    public:
    
	//constructori
     InitSenzor(uint8_t Id,uint8_t pinTrig, uint8_t pinEcho);
	 InitSenzor() ;
    
	//citeste distanta citita de senzor
     uint8_t citesteDistanta();
    
	 //returneaza id-ul senzorului
	 uint8_t getId();
             
    private:
 
     uint8_t PrivatePinTrig, PrivatePinEcho, distantaActuala, IdSenzor;
    

};
