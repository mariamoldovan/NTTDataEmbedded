#include "NewBuzzerclass.h"
#include <toneAC.h>
#include <stddef.h>
Buzzer* Buzzer::instance = 0 ;

Buzzer* Buzzer :: getinstance( 
             
             uint8_t DistantaSegment5 ,
             uint8_t DistantaSegment4 ,
             uint8_t DistantaSegment3 ,
             uint8_t DistantaSegment2 ,
             uint8_t DistantaSegment1 ,
             uint8_t DistantaSegment0 ,

             uint8_t FrecventaSegment5 ,
             uint8_t FrecventaSegment4 ,
             uint8_t FrecventaSegment3 ,
             uint8_t FrecventaSegment2 ,
             uint8_t FrecventaSegment1 ,
             uint8_t FrecventaSegment0 ,

             uint8_t DurataNotaSegment5 ,
             uint8_t DurataNotaSegment4 ,
             uint8_t DurataNotaSegment3 ,
             uint8_t DurataNotaSegment2 ,
             uint8_t DurataNotaSegment1 ,
             uint8_t DurataNotaSegment0 ,

             uint8_t NumarSenzori
            )
{
  if (instance == nullptr)
  {
    instance = new Buzzer (

      DistantaSegment5,
      DistantaSegment4 ,
      DistantaSegment3 ,
      DistantaSegment2 ,
      DistantaSegment1 ,
      DistantaSegment0 ,

      FrecventaSegment5,
      FrecventaSegment4 ,
      FrecventaSegment3,
      FrecventaSegment2 ,
      FrecventaSegment1 ,
      FrecventaSegment0 ,

      DurataNotaSegment5,
      DurataNotaSegment4,
      DurataNotaSegment3,
      DurataNotaSegment2,
      DurataNotaSegment1,
      DurataNotaSegment0,

      NumarSenzori
    );
  }

  return instance;
}

Buzzer ::  Buzzer (

  uint8_t DistantaSegment5 ,
  uint8_t DistantaSegment4 ,
  uint8_t DistantaSegment3 ,
  uint8_t DistantaSegment2 ,
  uint8_t DistantaSegment1 ,
  uint8_t DistantaSegment0 ,

  uint8_t FrecventaSegment5 ,
  uint8_t FrecventaSegment4 ,
  uint8_t FrecventaSegment3,
  uint8_t FrecventaSegment2 ,
  uint8_t FrecventaSegment1 ,
  uint8_t FrecventaSegment0 ,

  uint8_t DurataNotaSegment5 ,
  uint8_t DurataNotaSegment4 ,
  uint8_t DurataNotaSegment3 ,
  uint8_t DurataNotaSegment2 ,
  uint8_t DurataNotaSegment1 ,
  uint8_t DurataNotaSegment0 ,

  uint8_t NumarSenzori
) {

  PrivateDistantaSegment5 = DistantaSegment5;
  PrivateDistantaSegment4 = DistantaSegment4;
  PrivateDistantaSegment3 = DistantaSegment3;
  PrivateDistantaSegment2 = DistantaSegment2;
  PrivateDistantaSegment1 = DistantaSegment1;
  PrivateDistantaSegment0 = DistantaSegment0;

  PrivateFrecventaSegment5 = FrecventaSegment5;
  PrivateFrecventaSegment4 = FrecventaSegment4;
  PrivateFrecventaSegment5 = FrecventaSegment3;
  PrivateFrecventaSegment2 = FrecventaSegment2;
  PrivateFrecventaSegment1 = FrecventaSegment1;
  PrivateFrecventaSegment0 = FrecventaSegment0;

  PrivateDurataNotaSegment5 = DurataNotaSegment5;
  PrivateDurataNotaSegment4 = DurataNotaSegment4;
  PrivateDurataNotaSegment3 = DurataNotaSegment3;
  PrivateDurataNotaSegment2 = DurataNotaSegment2;
  PrivateDurataNotaSegment1 = DurataNotaSegment1;
  PrivateDurataNotaSegment0 = DurataNotaSegment0;
  
  PrivateNumarSenzori = NumarSenzori;
}

void Buzzer :: RingBuzzer(uint8_t SirDistante[], uint8_t volum)
{
  /*functie ce calculeaza distanta cea mai mica din vectorul de distante trimis de catre control
    dupa ce distanta este calculata buzzerul va incepe sa produca sunet in functie de paramtri dati
  */

  uint8_t DistantaMinima = SirDistante[0];
  for (uint8_t i = 0; i < PrivateNumarSenzori; i++) {
    if (DistantaMinima > SirDistante[i]) {
      DistantaMinima = SirDistante[i];
    }
  }
  Serial.print("Distanta minima :" );
  Serial.print(DistantaMinima);
  Serial.println();



  if (DistantaMinima < PrivateDistantaSegment5 && DistantaMinima > PrivateDistantaSegment4) {
    toneAC(PrivateFrecventaSegment5, volum, PrivateDurataNotaSegment5);
  }

  else if (DistantaMinima < PrivateDistantaSegment4 && DistantaMinima > PrivateDistantaSegment3) {
    toneAC(PrivateFrecventaSegment4, volum, PrivateDurataNotaSegment4);
    toneAC(PrivateFrecventaSegment4, volum, PrivateDurataNotaSegment4);

  }
  else if (DistantaMinima < PrivateDistantaSegment3 && DistantaMinima > PrivateDistantaSegment2) {
    toneAC(PrivateFrecventaSegment3, volum, PrivateDurataNotaSegment3);
    toneAC(PrivateFrecventaSegment3, volum, PrivateDurataNotaSegment3);
    toneAC(PrivateFrecventaSegment3, volum, PrivateDurataNotaSegment3);
  }
  else if (DistantaMinima < PrivateDistantaSegment2 && DistantaMinima > PrivateDistantaSegment1) {
    toneAC(PrivateFrecventaSegment2, volum, PrivateDurataNotaSegment2);
    toneAC(PrivateFrecventaSegment2, volum, PrivateDurataNotaSegment2);
    toneAC(PrivateFrecventaSegment2, volum, PrivateDurataNotaSegment2);
    toneAC(PrivateFrecventaSegment2, volum, PrivateDurataNotaSegment2);

  }
  else if (DistantaMinima < PrivateDistantaSegment1 && DistantaMinima > PrivateDistantaSegment0) {
    toneAC(PrivateFrecventaSegment1, volum, PrivateDurataNotaSegment1);
    toneAC(PrivateFrecventaSegment1, volum, PrivateDurataNotaSegment1);
    toneAC(PrivateFrecventaSegment1, volum, PrivateDurataNotaSegment1);
    toneAC(PrivateFrecventaSegment1, volum, PrivateDurataNotaSegment1);
    toneAC(PrivateFrecventaSegment1, volum, PrivateDurataNotaSegment1);
  }
  else if (DistantaMinima < PrivateDistantaSegment0) {
    toneAC(PrivateFrecventaSegment0, volum, PrivateDurataNotaSegment0);
    toneAC(PrivateFrecventaSegment0, volum, PrivateDurataNotaSegment0);
    toneAC(PrivateFrecventaSegment0, volum, PrivateDurataNotaSegment0);
    toneAC(PrivateFrecventaSegment0, volum, PrivateDurataNotaSegment0);
    toneAC(PrivateFrecventaSegment0, volum, PrivateDurataNotaSegment0);
    toneAC(PrivateFrecventaSegment0, volum, PrivateDurataNotaSegment0);

  }

}
void Buzzer :: SilentBuzzer() {
  /*metoda pentru a opri sunetul generat de buzzer*/
  noToneAC();
}







