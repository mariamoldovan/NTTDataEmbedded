#ifndef bluetoothCommunication
#define BT

#include "Arduino.h"
#include <SoftwareSerial.h> //Serial library

class Bluetooth
{
  public:
    static Bluetooth* getInstance(
                                    uint8_t PinRxBluetooth,
                                    uint8_t PinTxBluetooth, 
                                    uint16_t baudeRate, 
                                    uint8_t startFrame, 
                                    uint8_t endFrame, 
                                    uint8_t numarSenzori, 
                                    uint8_t numarCaractereFrame
                                    );
    void trimiteDateRaspberry(uint8_t distante[], uint16_t franaDeMana);
    uint8_t primesteDateRaspberry();
    
  private:
    uint16_t pini[];
    static Bluetooth* INSTANCE;
    SoftwareSerial *bluetoothCommunication;
    uint8_t startFrame;
    uint8_t endFrame;
    uint8_t numarSenzori;
    uint8_t numarCaractereFrame;

    Bluetooth(
              uint8_t PinRxBluetooth,
              uint8_t PinTxBluetooth, 
              uint16_t baudeRate, 
              uint8_t startFrame, 
              uint8_t endFrame, 
              uint8_t numarSenzori, 
              uint8_t numarCaractereFrame
              );
    void construireFrame(uint8_t distante[], uint8_t frameTransmisie[], uint16_t franaDeMana);
    uint8_t calculParitate(uint8_t dist);
};



#endif
