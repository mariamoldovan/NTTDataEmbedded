#include <NewPing.h>
#include "NewSenzor.h"
//#include "ConfigSenzorUltrasonic.h"

InitSenzor::InitSenzor(uint8_t Id,uint8_t pinTrig, uint8_t pinEcho, uint8_t VitezaSunetCM, uint8_t DistantaMaximaSenzor, uint8_t DistantaMinimaSenzor, uint8_t OutOfRange)
{
    PrivatePinTrig = pinTrig;
    PrivatePinEcho = pinEcho;
	PrivateIdSenzor = Id;
	PrivateVitezaSunetCM=VitezaSunetCM;
	PrivateDistantaMaximaSenzor=DistantaMaximaSenzor;
	PrivateDistantaMinimaSenzor=DistantaMinimaSenzor;
	PrivateOutOfRange=OutOfRange;
	
}

InitSenzor :: InitSenzor()
{
}

uint8_t InitSenzor::citesteDistanta()
{
  NewPing sonar(PrivatePinTrig, PrivatePinEcho, 400);
  uint16_t duration;
  duration = sonar.ping();
  PrivateDistantaActuala = (duration / 2) / PrivateVitezaSunetCM;
  
  vectorDistante[index]=PrivateDistantaActuala;
  index++;
  if(index<3)
  {
    if (PrivateDistantaActuala >= PrivateDistantaMaximaSenzor || PrivateDistantaActuala < PrivateDistantaMinimaSenzor) {
		return PrivateOutOfRange;
    }
    else {
		return PrivateDistantaActuala;
    }
  }
  else
  {
    media=(vectorDistante[0]+vectorDistante[1]+vectorDistante[2])/3;
    vectorDistante[0]=vectorDistante[1];
    vectorDistante[1]=vectorDistante[2];
    index--;
    if(media>=PrivateDistantaMaximaSenzor || media<PrivateDistantaMinimaSenzor)
      return PrivateOutOfRange;
    else
      return media;
  }
}

uint8_t InitSenzor::getId()
{
	return PrivateIdSenzor;
}