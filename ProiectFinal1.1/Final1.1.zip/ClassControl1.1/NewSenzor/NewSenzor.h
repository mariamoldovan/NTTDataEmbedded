#ifndef Senzor
#define Senzor

#include "Arduino.h"

class InitSenzor
{
  
    public:
    
	//constructori
     InitSenzor(uint8_t Id,uint8_t pinTrig, uint8_t pinEcho, uint8_t VitezaSunetCM, uint8_t DistantaMaximaSenzor, uint8_t DistantaMinimaSenzor, uint8_t OutOfRange);
	 InitSenzor() ;
    
	//citeste distanta citita de senzor
     uint8_t citesteDistanta();
    
	 //returneaza id-ul senzorului
	 uint8_t getId();
             
    private:
 
     uint8_t PrivatePinTrig, PrivatePinEcho, PrivateDistantaActuala, PrivateIdSenzor, PrivateVitezaSunetCM, PrivateDistantaMaximaSenzor, PrivateDistantaMinimaSenzor, PrivateOutOfRange;
	uint8_t index=0;
   uint8_t vectorDistante[3];
   uint8_t media;

};

#endif