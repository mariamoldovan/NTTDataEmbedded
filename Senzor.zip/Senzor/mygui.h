#ifndef MYGUI_H
#define MYGUI_H

#include <QWidget>
#include <QtGui>
#include <QtCore>
#include <vector>
#include "senzor.h"

#include <QHBoxLayout>

namespace Ui {
class MyGUI;
}

class MyGUI : public QWidget
{
    Q_OBJECT

public:
    explicit MyGUI(QWidget *parent = 0);
    ~MyGUI();

private:
    Ui::MyGUI *ui;
    int FREQ=1;

    std::vector<Senzor*> senzori;

    int getFREQ() const { return FREQ; }
    void setFREQ(const int FREQ);

    void updateSenzors(int distante[]);
    void receiveDistante();
    void initGUI();
    void constructSenzors();
    void myWait(int seconds);
public:
    void testSenzori();
public slots:
    void sendVolume(int volume);
    void changeVolumeLabel(int volume);
};

#endif // MYGUI_H
