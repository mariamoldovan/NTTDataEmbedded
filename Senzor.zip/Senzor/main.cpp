#include "mainwindow.h"
#include <QApplication>
#include "mygui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyGUI gui;
    gui.show();
    gui.testSenzori();

    return a.exec();
}
