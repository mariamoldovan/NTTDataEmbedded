#ifndef SENZORLAYOUT_H
#define SENZORLAYOUT_H
/*
#include <QLayout>

class SenzorLayout : public QLayout
{
public:
    SenzorLayout(QWidget *parent, int dist): QLayout(parent, 0, dist) {}
    SenzorLayout(QLayout *parent, int dist): QLayout(parent, dist) {}
    SenzorLayout(int dist): QLayout(dist) {}
    ~SenzorLayout();

    void addItem(QLayoutItem *item);
    QSize sizeHint() const;
    QSize minimumSize() const;
    int count() const;
    QLayoutItem *itemAt(int) const;
    QLayoutItem *takeAt(int);
    void setGeometry(const QRect &rect);

private:
    QList<QLayoutItem*> list;
};


*/
#endif // SENZORLAYOUT_H
