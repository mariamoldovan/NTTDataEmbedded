#ifndef bluetoothCommunication
#define BT

#include "Arduino.h"
#include <SoftwareSerial.h> //Serial library
#include "ConfigFileBluetooth.h"

class Bluetooth
{
  public:
    static Bluetooth* getInstance();
    void trimiteDateRaspberry(uint8_t distante[5], uint16_t franaDeMana);
    uint8_t primesteDateRaspberry();
    
  private:
    uint16_t pini[];
    static Bluetooth* INSTANCE;
    SoftwareSerial *bluetoothCommunication;
    //frameDistante *scheletFrame;

    Bluetooth();
    void construireFrame(uint8_t distante[], uint8_t frameTransmisie[], uint16_t franaDeMana);
    uint8_t calculParitate(uint8_t dist);
};



#endif
