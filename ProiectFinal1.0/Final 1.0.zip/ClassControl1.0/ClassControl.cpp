
#include "ClassControl.h"



Control :: Control(

  uint8_t PinSwitch,
  uint8_t EchoMijloc,
  uint8_t TrigMijloc,
  uint8_t EchoExteriorDreapta,
  uint8_t TrigExteriorDreapta,
  uint8_t EchoExteriorStanga,
  uint8_t TrigExteriorStanga,
  uint8_t EchoInteriorDreapta,
  uint8_t TrigInteriorDreapta,
  uint8_t EchoInteriorStanga,
  uint8_t TrigInteriorStanga,

  uint8_t IdMijloc,
  uint8_t IdExteriorDreapta,
  uint8_t IdExteriorStanga,
  uint8_t IdInteriorStanga,
  uint8_t IdInteriorDreapta,
  uint8_t NumarSenzori)

{
  
  PrivatePinSwitch = PinSwitch;
  PrivateEchoMijloc = EchoMijloc;
  PrivateTrigMijloc = TrigMijloc;
  PrivateEchoExteriorDreapta = EchoExteriorDreapta;
  PrivateTrigExteriorDreapta = TrigExteriorDreapta;
  PrivateEchoExteriorStanga = EchoExteriorStanga;
  PrivateTrigExteriorStanga = TrigExteriorStanga;
  PrivateEchoInteriorDreapta = EchoInteriorDreapta;
  PrivateTrigInteriorDreapta = TrigInteriorDreapta;
  PrivateEchoInteriorStanga = EchoInteriorStanga;
  PrivateTrigInteriorStanga = TrigInteriorStanga;

  PrivateIdMijloc = IdMijloc;
  PrivateIdExteriorDreapta = IdExteriorDreapta;
  PrivateIdExteriorStanga = IdExteriorStanga;
  PrivateIdInteriorStanga = IdInteriorStanga;
  PrivateIdInteriorDreapta = IdInteriorDreapta;
  PrivateNumarSenzori = NumarSenzori;
  Serial.print("Obiect control creat");
}


void Control :: trimiteRasberry(uint8_t data[],uint8_t FranadeMana) {
  (*BluetoothObject).trimiteDateRaspberry(data,FranadeMana);
}

uint8_t * Control :: VectorDistanteSenzori() {
  uint8_t *VectorDistante;
  VectorDistante = ObjectSenzori.getDistance();
  return VectorDistante;
}

void Control :: AlertaBuzzer(uint8_t SirDistante[], uint8_t volum) {
  (*BuzzerObject).RingBuzzer( SirDistante , volum );

}

void Control :: StopBuzzer() {
  (*BuzzerObject).SilentBuzzer();
}

void Control :: initializare() {

  ObjectSenzori = SetSenzori(
    
                    PrivateEchoMijloc,
                    PrivateTrigMijloc,
                    PrivateEchoExteriorDreapta,
                    PrivateTrigExteriorDreapta,
                    PrivateEchoExteriorStanga,
                    PrivateTrigExteriorStanga,
                    PrivateEchoInteriorDreapta,
                    PrivateTrigInteriorDreapta,
                    PrivateEchoInteriorStanga,
                    PrivateTrigInteriorStanga,

                    PrivateIdMijloc,
                    PrivateIdExteriorDreapta,
                    PrivateIdExteriorStanga,
                    PrivateIdInteriorStanga,
                    PrivateIdInteriorDreapta
                    
                  );

  BuzzerObject = Buzzer :: getinstance();
  BluetoothObject=Bluetooth::getInstance();
  ObjectSenzori.initializareSenzori();

}

uint8_t Control :: VolumBluetooth(){
    uint8_t SetareVolum=(*BluetoothObject).primesteDateRaspberry();
    return SetareVolum;
}
void Control:: TaskLoop() {
  
  pinMode(PrivatePinSwitch, INPUT);
  digitalWrite(PrivatePinSwitch, HIGH);
 
  uint8_t sirDistante[5];
  uint8_t *citire = VectorDistanteSenzori();

  for (int i = 0; i < PrivateNumarSenzori; i++) {
    sirDistante[i] = citire[i];
  }
  
  
 if (digitalRead(PrivatePinSwitch) == HIGH) {
    uint8_t volum = VolumBluetooth();
    AlertaBuzzer(sirDistante, volum);
    FranadeMana=0;
    trimiteRasberry(sirDistante,FranadeMana);
  }
  else {
    StopBuzzer();
    FranadeMana=1;
    trimiteRasberry(sirDistante,FranadeMana);
  }

}


