const uint8_t VitezaSunetCM=29;
const uint8_t DistantaMaximaSenzor=150;
const uint8_t DistantaMinimaSenzor=2;
const uint8_t OutOfRange=160;
  