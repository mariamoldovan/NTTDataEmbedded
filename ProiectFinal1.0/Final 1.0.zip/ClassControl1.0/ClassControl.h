
#ifndef control
#define control

#include <Buzzerclass.h>
#include <ConfigFileSenzor.h>
#include <setSnz.h>
#include <Bluetooth.h>


#if (ARDUINO >=100)
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

class Control {

  private :

    //pini frana de mana
    uint8_t PrivatePinSwitch;
    
    //id pentru fiecare senzor
    uint8_t PrivateIdMijloc;
    uint8_t PrivateIdExteriorDreapta;
    uint8_t PrivateIdExteriorStanga;
    uint8_t PrivateIdInteriorStanga;
    uint8_t PrivateIdInteriorDreapta;


    //pini pentru senzori ultrasonici
    uint8_t  PrivateEchoMijloc;
    uint8_t  PrivateTrigMijloc;
    uint8_t  PrivateEchoExteriorDreapta;
    uint8_t  PrivateTrigExteriorDreapta;
    uint8_t  PrivateEchoExteriorStanga;
    uint8_t  PrivateTrigExteriorStanga;
    uint8_t  PrivateEchoInteriorDreapta;
    uint8_t  PrivateTrigInteriorDreapta;
    uint8_t  PrivateEchoInteriorStanga;
    uint8_t  PrivateTrigInteriorStanga;
    uint8_t  PrivateNumarSenzori;

    uint8_t FranadeMana;

  public:
  
    SetSenzori ObjectSenzori; //obiect pentru a seta senzori
    Buzzer *BuzzerObject;
    Bluetooth *BluetoothObject;

    Control(

      
      uint8_t PinSwitch,
      uint8_t EchoMijloc,
      uint8_t TrigMijloc,
      uint8_t EchoExteriorDreapta,
      uint8_t TrigExteriorDreapta,
      uint8_t EchoExteriorStanga,
      uint8_t TrigExteriorStanga,
      uint8_t EchoInteriorDreapta,
      uint8_t TrigInteriorDreapta,
      uint8_t EchoInteriorStanga,
      uint8_t TrigInteriorStanga,

      uint8_t IdMijloc,
      uint8_t IdExteriorDreapta,
      uint8_t IdExteriorStanga,
      uint8_t IdInteriorStanga,
      uint8_t IdInteriorDreapta,
      uint8_t NumarSenzori );

    //Metode
    void AlertaBuzzer(uint8_t *distanta, uint8_t volum ); //se trimite cea mai mica distanta
    uint8_t *VectorDistanteSenzori();//returneaza un vector cu toate distantele
    void StopBuzzer();//functie pentru a opri sunetul generat de buzzer cand frana de mana este actionata
    void initializare();//in aceasta functie initializam obiectele ce o sa fie folosite de clasa control
    void TaskLoop();//functia ce va apelata in loop-ul din sketch
    void trimiteRasberry(uint8_t data[],uint8_t FranadeMana);//necesar modulul 
    uint8_t VolumBluetooth();


};
#endif


