
const uint8_t DistantaSegment5 = 150;
const uint8_t DistantaSegment4 = 120;
const uint8_t DistantaSegment3 = 90;
const uint8_t DistantaSegment2 = 60;
const uint8_t DistantaSegment1=  30;
const uint8_t DistantaSegment0=  15;

const uint8_t FrecventaSegment5 = 45;
const uint8_t FrecventaSegment4 = 75;
const uint8_t FrecventaSegment3 = 95;
const uint8_t FrecventaSegment2 = 115;
const uint8_t FrecventaSegment1 = 135;
const uint8_t FrecventaSegment0 = 155;

const uint8_t DurataNotaSegment5 = 13;
const uint8_t DurataNotaSegment4 = 11;
const uint8_t DurataNotaSegment3 = 9;
const uint8_t DurataNotaSegment2 = 7;
const uint8_t DurataNotaSegment1 = 5;
const uint8_t DurataNotaSegment0 = 3;

const uint8_t DefaultVolum =5;
const uint8_t NumarSenzori =5;
