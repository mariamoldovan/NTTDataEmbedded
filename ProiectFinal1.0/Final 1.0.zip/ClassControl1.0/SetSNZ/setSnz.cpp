#include "setSnz.h"

SetSenzori :: SetSenzori(){}

SetSenzori :: SetSenzori(
      uint8_t EchoMijloc,
      uint8_t TrigMijloc,
      uint8_t EchoExteriorDreapta,
      uint8_t TrigExteriorDreapta,
      uint8_t  EchoExteriorStanga,
      uint8_t TrigExteriorStanga,
      uint8_t EchoInteriorDreapta,
      uint8_t TrigInteriorDreapta,
      uint8_t EchoInteriorStanga,
      uint8_t TrigInteriorStanga,
      uint8_t IdMijloc,
      uint8_t IdExteriorDreapta,
      uint8_t IdExteriorStanga,
      uint8_t IdInteriorStanga,
      uint8_t IdInteriorDreapta )
{ 
         PrivateEchoMijloc=EchoMijloc;
         PrivateTrigMijloc=TrigMijloc;
         PrivateEchoExteriorDreapta=EchoExteriorDreapta;
         PrivateTrigExteriorDreapta=TrigExteriorDreapta;
         PrivateEchoExteriorStanga=EchoExteriorStanga;
         PrivateTrigExteriorStanga=TrigExteriorStanga;
         PrivateEchoInteriorDreapta=EchoInteriorDreapta;
         PrivateTrigInteriorDreapta=TrigInteriorDreapta;
         PrivateEchoInteriorStanga=EchoInteriorStanga;
         PrivateTrigInteriorStanga=TrigInteriorStanga;
         PrivateIdMijloc=IdMijloc;
         PrivateIdExteriorDreapta=IdExteriorDreapta;
         PrivateIdExteriorStanga=IdExteriorStanga;
         PrivateIdInteriorStanga=IdInteriorStanga;
         PrivateIdInteriorDreapta=IdInteriorDreapta; 
}

void SetSenzori :: initializareSenzori(){
  
    Mijloc=InitSenzor (PrivateIdMijloc,PrivateTrigMijloc,PrivateEchoMijloc);
    ExteriorDreapta=InitSenzor (PrivateIdExteriorDreapta,PrivateTrigExteriorDreapta,PrivateEchoExteriorDreapta);
    ExteriorStanga=InitSenzor(PrivateIdExteriorStanga,PrivateTrigExteriorStanga,PrivateEchoExteriorStanga);
    InteriorDreapta=InitSenzor(PrivateIdInteriorDreapta,PrivateTrigInteriorDreapta,PrivateEchoInteriorDreapta);
    InteriorStanga=InitSenzor (PrivateIdInteriorStanga,PrivateTrigInteriorStanga,PrivateEchoInteriorStanga);
}

uint8_t* SetSenzori :: getDistance()
{
    sirDistante[0]=ExteriorStanga.citesteDistanta();
    sirDistante[1]=InteriorStanga.citesteDistanta();
    sirDistante[2]=Mijloc.citesteDistanta();
    sirDistante[3]=InteriorDreapta.citesteDistanta();
    sirDistante[4]=ExteriorDreapta.citesteDistanta(); 
    
	
	//Serial.println();
	for(int i=0;i<5;i++){
      Serial.print(i+1);
      Serial.print(". -------------- ");
      Serial.print(sirDistante[i]);
      Serial.print(" cm");
      Serial.println();
    }
    Serial.println();
    return sirDistante;
}


