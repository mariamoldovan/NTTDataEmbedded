
#ifndef control
#define control

#include <NewBuzzerClass.h>
#include <ConfigFile.h>
#include <NewSetSenzori.h>
#include <NewBluetooth.h>


#if (ARDUINO >=100)
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

class Control {

  private :

    //pini bluetooth
    uint8_t PrivatePinRxBluetooth;
    uint8_t PrivatePinTxBluetooth;
    uint16_t PrivatebaudeRateBluetooth;

    //pini frana de mana
    uint8_t PrivatePinSwitch;

    //id pentru fiecare senzor
    uint8_t PrivateIdMijloc;
    uint8_t PrivateIdExteriorDreapta;
    uint8_t PrivateIdExteriorStanga;
    uint8_t PrivateIdInteriorStanga;
    uint8_t PrivateIdInteriorDreapta;


    //pini pentru senzori ultrasonici
    uint8_t  PrivateEchoMijloc;
    uint8_t  PrivateTrigMijloc;
    uint8_t  PrivateEchoExteriorDreapta;
    uint8_t  PrivateTrigExteriorDreapta;
    uint8_t  PrivateEchoExteriorStanga;
    uint8_t  PrivateTrigExteriorStanga;
    uint8_t  PrivateEchoInteriorDreapta;
    uint8_t  PrivateTrigInteriorDreapta;
    uint8_t  PrivateEchoInteriorStanga;
    uint8_t  PrivateTrigInteriorStanga;
    uint8_t  PrivateNumarSenzori;

    uint8_t PrivateVitezaSunetCM;
    uint8_t PrivateDistantaMaximaSenzor;
    uint8_t PrivateDistantaMinimaSenzor;
    uint8_t PrivateOutOfRange;



    //variabila care va fi transmisa ca paramtru la bluetooth
    uint8_t FranadeMana;

    //parametri buzzer
    uint8_t PrivateDistantaSegment5 ;
    uint8_t PrivateDistantaSegment4;
    uint8_t PrivateDistantaSegment3 ;
    uint8_t PrivateDistantaSegment2 ;
    uint8_t PrivateDistantaSegment1 ;
    uint8_t PrivateDistantaSegment0 ;

    uint8_t PrivateFrecventaSegment5 ;
    uint8_t PrivateFrecventaSegment4 ;
    uint8_t PrivateFrecventaSegment3 ;
    uint8_t PrivateFrecventaSegment2 ;
    uint8_t PrivateFrecventaSegment1 ;
    uint8_t PrivateFrecventaSegment0 ;

    uint8_t PrivateDurataNotaSegment5 ;
    uint8_t PrivateDurataNotaSegment4 ;
    uint8_t PrivateDurataNotaSegment3 ;
    uint8_t PrivateDurataNotaSegment2 ;
    uint8_t PrivateDurataNotaSegment1 ;
    uint8_t PrivateDurataNotaSegment0 ;


    //parametri frame
    uint8_t PrivatestartFrame ;
    uint8_t PrivateendFrame ;
    uint8_t PrivateNrCaractereFrame;

  public:

    // obiecte pentru fiecare modul
    SetSenzori ObjectSenzori;
    Buzzer *BuzzerObject;
    Bluetooth *BluetoothObject;

    Control(

      uint8_t PinRxBluetooth,
      uint8_t PinTxBluetooth,
      uint16_t baudeRateBluetooth,

      uint8_t PinSwitch,

      uint8_t EchoMijloc,
      uint8_t TrigMijloc,
      uint8_t EchoExteriorDreapta,
      uint8_t TrigExteriorDreapta,
      uint8_t EchoExteriorStanga,
      uint8_t TrigExteriorStanga,
      uint8_t EchoInteriorDreapta,
      uint8_t TrigInteriorDreapta,
      uint8_t EchoInteriorStanga,
      uint8_t TrigInteriorStanga,


      uint8_t IdMijloc,
      uint8_t IdExteriorDreapta,
      uint8_t IdExteriorStanga,
      uint8_t IdInteriorStanga,
      uint8_t IdInteriorDreapta,
      uint8_t NumarSenzori,

      uint8_t VitezaSunetCM,
      uint8_t DistantaMaximaSenzor,
      uint8_t DistantaMinimaSenzor,
      uint8_t OutOfRange,

      uint8_t DistantaSegment5 ,
      uint8_t DistantaSegment4 ,
      uint8_t DistantaSegment3 ,
      uint8_t DistantaSegment2 ,
      uint8_t DistantaSegment1 ,
      uint8_t DistantaSegment0 ,

      uint8_t FrecventaSegment5 ,
      uint8_t FrecventaSegment4 ,
      uint8_t FrecventaSegment3 ,
      uint8_t FrecventaSegment2 ,
      uint8_t FrecventaSegment1 ,
      uint8_t FrecventaSegment0 ,

      uint8_t DurataNotaSegment5 ,
      uint8_t DurataNotaSegment4 ,
      uint8_t DurataNotaSegment3 ,
      uint8_t DurataNotaSegment2 ,
      uint8_t DurataNotaSegment1 ,
      uint8_t DurataNotaSegment0 ,

      uint8_t startFrame,
      uint8_t endFrame,
      uint8_t NrCaractereFrame);

    //Metode
    void AlertaBuzzer(uint8_t *distanta, uint8_t volum ); //se trimite cea mai mica distanta
    uint8_t *VectorDistanteSenzori();//returneaza un vector cu toate distantele
    void StopBuzzer();//functie pentru a opri sunetul generat de buzzer cand frana de mana este actionata
    void InitializareObiecte();//in aceasta functie initializam obiectele ce o sa fie folosite de clasa control
    void TaskLoop();//functia ce va apelata in loop-ul din sketch
    void trimiteRasberry(uint8_t Sirdistante[], uint8_t FranadeMana); //metoda ce trimite la HMI sirul de distante si daca fran de mana este trasa sau nu
    uint8_t VolumInterfata();//metoda ce modifica vilumul buzzer-ului in functie de valoarea data de HMI


};
#endif


