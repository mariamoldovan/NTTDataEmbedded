
#include "NewClassControl.h"



Control ::  Control(

  uint8_t PinRxBluetooth,
  uint8_t PinTxBluetooth,
  uint16_t baudeRateBluetooth,

  uint8_t PinSwitch,

  uint8_t EchoMijloc,
  uint8_t TrigMijloc,
  uint8_t EchoExteriorDreapta,
  uint8_t TrigExteriorDreapta,
  uint8_t EchoExteriorStanga,
  uint8_t TrigExteriorStanga,
  uint8_t EchoInteriorDreapta,
  uint8_t TrigInteriorDreapta,
  uint8_t EchoInteriorStanga,
  uint8_t TrigInteriorStanga,

  uint8_t IdMijloc,
  uint8_t IdExteriorDreapta,
  uint8_t IdExteriorStanga,
  uint8_t IdInteriorStanga,
  uint8_t IdInteriorDreapta,
  uint8_t NumarSenzori,

  uint8_t VitezaSunetCM,
  uint8_t DistantaMaximaSenzor,
  uint8_t DistantaMinimaSenzor,
  uint8_t OutOfRange,

  uint8_t DistantaSegment5 ,
  uint8_t DistantaSegment4 ,
  uint8_t DistantaSegment3 ,
  uint8_t DistantaSegment2 ,
  uint8_t DistantaSegment1 ,
  uint8_t DistantaSegment0 ,

  uint8_t FrecventaSegment5 ,
  uint8_t FrecventaSegment4 ,
  uint8_t FrecventaSegment3 ,
  uint8_t FrecventaSegment2 ,
  uint8_t FrecventaSegment1 ,
  uint8_t FrecventaSegment0 ,

  uint8_t DurataNotaSegment5 ,
  uint8_t DurataNotaSegment4 ,
  uint8_t DurataNotaSegment3 ,
  uint8_t DurataNotaSegment2 ,
  uint8_t DurataNotaSegment1 ,
  uint8_t DurataNotaSegment0 ,

  uint8_t startFrame,
  uint8_t endFrame,
  uint8_t NrCaractereFrame)
{

  PrivatebaudeRateBluetooth = baudeRateBluetooth;
  PrivatePinSwitch = PinSwitch;

  PrivateEchoMijloc = EchoMijloc;
  PrivateTrigMijloc = TrigMijloc;
  PrivateEchoExteriorDreapta = EchoExteriorDreapta;
  PrivateTrigExteriorDreapta = TrigExteriorDreapta;
  PrivateEchoExteriorStanga = EchoExteriorStanga;
  PrivateTrigExteriorStanga = TrigExteriorStanga;
  PrivateEchoInteriorDreapta = EchoInteriorDreapta;
  PrivateTrigInteriorDreapta = TrigInteriorDreapta;
  PrivateEchoInteriorStanga = EchoInteriorStanga;
  PrivateTrigInteriorStanga = TrigInteriorStanga;

  PrivateIdMijloc = IdMijloc;
  PrivateIdExteriorDreapta = IdExteriorDreapta;
  PrivateIdExteriorStanga = IdExteriorStanga;
  PrivateIdInteriorStanga = IdInteriorStanga;
  PrivateIdInteriorDreapta = IdInteriorDreapta;
  PrivateNumarSenzori = NumarSenzori;

  PrivateVitezaSunetCM = VitezaSunetCM;
  PrivateDistantaMaximaSenzor = DistantaMaximaSenzor;
  PrivateDistantaMinimaSenzor = DistantaMinimaSenzor;
  PrivateOutOfRange = OutOfRange;

  PrivateDistantaSegment5 = DistantaSegment5;
  PrivateDistantaSegment4 = DistantaSegment4;
  PrivateDistantaSegment3 = DistantaSegment3;
  PrivateDistantaSegment2 = DistantaSegment2;
  PrivateDistantaSegment1 = DistantaSegment1;
  PrivateDistantaSegment0 = DistantaSegment0;

  PrivateFrecventaSegment5 = FrecventaSegment5;
  PrivateFrecventaSegment4 = FrecventaSegment4;
  PrivateFrecventaSegment5 = FrecventaSegment3;
  PrivateFrecventaSegment2 = FrecventaSegment2;
  PrivateFrecventaSegment1 = FrecventaSegment1;
  PrivateFrecventaSegment0 = FrecventaSegment0;

  PrivateDurataNotaSegment5 = DurataNotaSegment5;
  PrivateDurataNotaSegment4 = DurataNotaSegment4;
  PrivateDurataNotaSegment3 = DurataNotaSegment3;
  PrivateDurataNotaSegment2 = DurataNotaSegment2;
  PrivateDurataNotaSegment1 = DurataNotaSegment1;
  PrivateDurataNotaSegment0 = DurataNotaSegment0;

  PrivateNumarSenzori = NumarSenzori;
  PrivatestartFrame = startFrame;
  PrivateendFrame = endFrame;
  PrivateNrCaractereFrame = NrCaractereFrame;
  PrivatePinRxBluetooth = PinRxBluetooth;
  PrivatePinTxBluetooth = PinTxBluetooth;

  Serial.print("Obiect control creat");
}


void Control :: trimiteRasberry(uint8_t data[], uint8_t FranadeMana) {
  (*BluetoothObject).trimiteDateRaspberry(data, FranadeMana);
}

uint8_t * Control :: VectorDistanteSenzori() {
  uint8_t *VectorDistante;
  VectorDistante = ObjectSenzori.getDistance();
  return VectorDistante;
}

void Control :: AlertaBuzzer(uint8_t SirDistante[], uint8_t volum) {
  (*BuzzerObject).RingBuzzer( SirDistante , volum );

}

void Control :: StopBuzzer() {
  (*BuzzerObject).SilentBuzzer();
}

void Control :: InitializareObiecte() {

  ObjectSenzori = SetSenzori(

                    PrivateEchoMijloc,
                    PrivateTrigMijloc,
                    PrivateEchoExteriorDreapta,
                    PrivateTrigExteriorDreapta,
                    PrivateEchoExteriorStanga,
                    PrivateTrigExteriorStanga,
                    PrivateEchoInteriorDreapta,
                    PrivateTrigInteriorDreapta,
                    PrivateEchoInteriorStanga,
                    PrivateTrigInteriorStanga,

                    PrivateIdMijloc,
                    PrivateIdExteriorDreapta,
                    PrivateIdExteriorStanga,
                    PrivateIdInteriorStanga,
                    PrivateIdInteriorDreapta,

                    PrivateVitezaSunetCM ,
                    PrivateDistantaMaximaSenzor ,
                    PrivateDistantaMinimaSenzor ,
                    PrivateOutOfRange 

                  );

  BuzzerObject = Buzzer :: getinstance(

                   PrivateDistantaSegment5 ,
                   PrivateDistantaSegment4 ,
                   PrivateDistantaSegment3 ,
                   PrivateDistantaSegment2 ,
                   PrivateDistantaSegment1 ,
                   PrivateDistantaSegment0 ,

                   PrivateFrecventaSegment5 ,
                   PrivateFrecventaSegment4 ,
                   PrivateFrecventaSegment3 ,
                   PrivateFrecventaSegment2 ,
                   PrivateFrecventaSegment1 ,
                   PrivateFrecventaSegment0 ,

                   PrivateDurataNotaSegment5 ,
                   PrivateDurataNotaSegment4 ,
                   PrivateDurataNotaSegment3 ,
                   PrivateDurataNotaSegment2 ,
                   PrivateDurataNotaSegment1 ,
                   PrivateDurataNotaSegment0 ,

                   PrivateNumarSenzori
                 );
  ObjectSenzori.initializareSenzori();

  
  BluetoothObject = Bluetooth ::getInstance(
                      PrivatePinRxBluetooth,
                      PrivatePinTxBluetooth,
                      PrivatebaudeRateBluetooth,
                      PrivatestartFrame,
                      PrivateendFrame,
                      PrivateNumarSenzori,
                      PrivateNrCaractereFrame);



}

uint8_t Control :: VolumInterfata() {
  uint8_t SetareVolum = (*BluetoothObject).primesteDateRaspberry();
  Serial.print("Volum buzzer : ");
  Serial.print(SetareVolum);
  Serial.println();
  return SetareVolum;
}

void Control:: TaskLoop() {

  pinMode(PrivatePinSwitch, INPUT);
  digitalWrite(PrivatePinSwitch, HIGH);

  uint8_t sirDistante[PrivateNumarSenzori];
  uint8_t *citire = VectorDistanteSenzori();

  for (int i = 0; i < PrivateNumarSenzori; i++) {
    sirDistante[i] = citire[i];
  }


  if (digitalRead(PrivatePinSwitch) == HIGH) {
    uint8_t volum = VolumInterfata();
    AlertaBuzzer(sirDistante, volum);
    FranadeMana = 0;
    trimiteRasberry(sirDistante, FranadeMana);
  }
  else {
    StopBuzzer();
    FranadeMana = 1;
    trimiteRasberry(sirDistante, FranadeMana);
  }

}


