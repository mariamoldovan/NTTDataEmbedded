#ifndef setsnz
#define setsnz

#include <NewSenzor.h>

#if (ARDUINO >=100)
  #include "Arduino.h"
#else 
  #include "WProgram.h"
  #endif


class SetSenzori{
  private :

    //id pentru fiecare senzor
    uint8_t PrivateIdMijloc; 
    uint8_t PrivateIdExteriorDreapta;
    uint8_t PrivateIdExteriorStanga;
    uint8_t PrivateIdInteriorStanga;
    uint8_t PrivateIdInteriorDreapta;
	uint8_t sirDistante[5];
 
    //pini pentru senzori ultrasonici 
     uint8_t  PrivateEchoMijloc;
     uint8_t  PrivateTrigMijloc;
     uint8_t  PrivateEchoExteriorDreapta;
     uint8_t  PrivateTrigExteriorDreapta;
     uint8_t  PrivateEchoExteriorStanga;
     uint8_t  PrivateTrigExteriorStanga;
     uint8_t  PrivateEchoInteriorDreapta;
     uint8_t  PrivateTrigInteriorDreapta;
     uint8_t  PrivateEchoInteriorStanga;
     uint8_t  PrivateTrigInteriorStanga;
   
     InitSenzor Mijloc;
     InitSenzor ExteriorDreapta;
     InitSenzor ExteriorStanga;
     InitSenzor InteriorDreapta;
     InitSenzor InteriorStanga;
	 
	 uint8_t PrivateVitezaSunetCM; 
	 uint8_t PrivateDistantaMaximaSenzor;
	 uint8_t PrivateDistantaMinimaSenzor; 
	 uint8_t PrivateOutOfRange;

     public:
		SetSenzori();
        SetSenzori(
          uint8_t EchoMijloc,
          uint8_t TrigMijloc,
          uint8_t EchoExteriorDreapta,
          uint8_t TrigExteriorDreapta,
          uint8_t EchoExteriorStanga,
          uint8_t TrigExteriorStanga,
          uint8_t EchoInteriorDreapta,
          uint8_t TrigInteriorDreapta,
          uint8_t EchoInteriorStanga,
          uint8_t TrigInteriorStanga,
          uint8_t IdMijloc,
          uint8_t IdExteriorDreapta,
          uint8_t IdExteriorStanga,
          uint8_t IdInteriorStanga,
          uint8_t IdInteriorDreapta,
	    	uint8_t VitezaSunetCM,
         	uint8_t DistantaMaximaSenzor,
          uint8_t DistantaMinimaSenzor,
          uint8_t OutOfRange


	);

        void initializareSenzori(); 

        uint8_t* getDistance();
	
};
#endif

